import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io' show Platform;
import 'package:flutter/foundation.dart';

class Services {
  static Map<String, dynamic>? currentUser;
  static String? authToken;

  // ✅ FIX 1: IP corrigée pour téléphone physique sur même réseau WiFi
  static String get baseUrl {
    if (kIsWeb) return 'http://localhost:3000';
    if (Platform.isAndroid)
      return 'http://192.168.43.93:3000'; // IP Windows réelle
    return 'http://localhost:3000';
  }

  static Map<String, String> get _headers => {
    'Content-Type': 'application/json',
    if (authToken != null) 'Authorization': 'Bearer $authToken',
  };

  // ✅ FIX 2: Charger la session au démarrage de l'app
  static Future<void> loadSession() async {
    final prefs = await SharedPreferences.getInstance();
    authToken = prefs.getString('auth_token');
    final userStr = prefs.getString('current_user');
    if (userStr != null && userStr.isNotEmpty) {
      try {
        currentUser = jsonDecode(userStr);
      } catch (_) {}
    }
  }

  // 🔐 Auth
  static Future<Map<String, dynamic>> register({
    required String nom,
    required String email,
    required String motDePasse,
    required String role,
    String? specialite,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/register'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'nom': nom,
          'email': email,
          'mot_de_passe': motDePasse,
          'role': role,
          if (specialite != null && specialite.isNotEmpty)
            'specialite': specialite,
        }),
      );
      if (response.statusCode == 201) {
        return {'success': true, 'data': jsonDecode(response.body)};
      }
      try {
        final err = jsonDecode(response.body);
        return {
          'success': false,
          'message': err['error'] ?? "Erreur d'inscription",
        };
      } catch (_) {
        return {
          'success': false,
          'message': 'Erreur serveur (${response.statusCode})',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message':
            'Impossible de joindre le serveur. Vérifiez votre connexion.',
      };
    }
  }

  static Future<Map<String, dynamic>> login({
    required String email,
    required String motDePasse,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email, 'mot_de_passe': motDePasse}),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        authToken = data['token'];
        currentUser = data['user'];
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('auth_token', authToken ?? '');
        await prefs.setString('current_user', jsonEncode(currentUser));
        return {'success': true, 'user': data['user'], 'token': data['token']};
      }
      try {
        final err = jsonDecode(response.body);
        return {
          'success': false,
          'message': err['error'] ?? 'Erreur de connexion',
        };
      } catch (_) {
        return {
          'success': false,
          'message': 'Erreur serveur (${response.statusCode})',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'message':
            'Impossible de joindre le serveur. Vérifiez votre connexion.',
      };
    }
  }

  // 🚪 Déconnexion
  static Future<void> clearSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
    await prefs.remove('current_user');
    authToken = null;
    currentUser = null;
  }

  // 👥 Users
  static Future<Map<String, dynamic>> fetchUsers() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/users'),
        headers: _headers,
      );
      if (response.statusCode == 200) {
        return {'success': true, 'data': jsonDecode(response.body)};
      }
      return {'success': false, 'message': 'Erreur lors du chargement'};
    } catch (e) {
      return {'success': false, 'message': 'Impossible de joindre le serveur.'};
    }
  }

  // 🏢 Signalements
  static Future<Map<String, dynamic>> createSignalement({
    required String titre,
    required String description,
    required String batiment,
    required String adresse,
    required String quartier,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/signalements'),
        headers: _headers,
        body: jsonEncode({
          'titre': titre,
          'description': description,
          'batiment': batiment,
          'adresse': adresse,
          'quartier': quartier,
        }),
      );
      if (response.statusCode == 201) {
        final data = jsonDecode(response.body);
        // ✅ FIX 3: le backend renvoie id_signalement ET id
        final createdId = int.tryParse(
          (data['id_signalement'] ?? data['id'] ?? '').toString(),
        );
        return {'success': true, 'data': data, 'createdId': createdId};
      }
      try {
        final err = jsonDecode(response.body);
        return {
          'success': false,
          'message': err['error'] ?? "Erreur lors de l'envoi",
        };
      } catch (_) {
        return {
          'success': false,
          'message': 'Erreur serveur (${response.statusCode})',
        };
      }
    } catch (e) {
      return {'success': false, 'message': 'Impossible de joindre le serveur.'};
    }
  }

  static Future<Map<String, dynamic>> loadSignalements() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/signalements'),
        headers: _headers,
      );
      if (response.statusCode == 200) {
        return {'success': true, 'data': jsonDecode(response.body)};
      }
      return {'success': false, 'message': 'Erreur lors du chargement'};
    } catch (e) {
      return {'success': false, 'message': 'Impossible de joindre le serveur.'};
    }
  }

  static Future<Map<String, dynamic>> getSignalementById(
    int idSignalement,
  ) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/signalements/$idSignalement'),
        headers: _headers,
      );
      if (response.statusCode == 200) {
        return {'success': true, 'data': jsonDecode(response.body)};
      }
      return {'success': false, 'message': 'Signalement introuvable'};
    } catch (e) {
      return {'success': false, 'message': 'Impossible de joindre le serveur.'};
    }
  }

  static Future<Map<String, dynamic>> updateSignalement({
    required int id,
    required String titre,
    required String description,
    required String batiment,
    required String adresse,
    required String quartier,
    required String statut,
  }) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/signalements/$id'),
        headers: _headers,
        body: jsonEncode({
          'titre': titre,
          'description': description,
          'batiment': batiment,
          'adresse': adresse,
          'quartier': quartier,
          'statut': statut,
        }),
      );
      if (response.statusCode == 200) {
        return {'success': true, 'data': jsonDecode(response.body)};
      }
      return {'success': false, 'message': 'Erreur de mise à jour'};
    } catch (e) {
      return {'success': false, 'message': 'Impossible de joindre le serveur.'};
    }
  }

  static Future<Map<String, dynamic>> deleteSignalement(int id) async {
    try {
      final response = await http.delete(
        Uri.parse('$baseUrl/signalements/$id'),
        headers: _headers,
      );
      if (response.statusCode == 200) {
        return {'success': true, 'message': 'Signalement supprimé'};
      }
      return {'success': false, 'message': 'Erreur de suppression'};
    } catch (e) {
      return {'success': false, 'message': 'Impossible de joindre le serveur.'};
    }
  }

  // 📊 Statistiques
  static Future<Map<String, dynamic>> loadStats() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/signalements/stats'),
        headers: _headers,
      );
      if (response.statusCode == 200) {
        return {'success': true, 'data': jsonDecode(response.body)};
      }
      return {
        'success': false,
        'message': 'Erreur lors du chargement des stats',
      };
    } catch (e) {
      return {'success': false, 'message': 'Impossible de joindre le serveur.'};
    }
  }

  // 💬 Commentaires
  static Future<List<Map<String, dynamic>>> loadComments(
    int signalementId,
  ) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/signalements/$signalementId/commentaires'),
        headers: _headers,
      );
      if (response.statusCode == 200) {
        return List<Map<String, dynamic>>.from(jsonDecode(response.body));
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  static Future<Map<String, dynamic>> sendComment({
    required String message,
    required int signalementId,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/signalements/$signalementId/commentaires'),
        headers: _headers,
        // ✅ FIX 4: envoyer les deux champs, le backend accepte 'contenu' ou 'message'
        body: jsonEncode({'contenu': message, 'message': message}),
      );
      if (response.statusCode == 201) {
        return {'success': true, 'data': jsonDecode(response.body)};
      }
      try {
        final err = jsonDecode(response.body);
        return {'success': false, 'message': err['error'] ?? "Erreur d'envoi"};
      } catch (_) {
        return {
          'success': false,
          'message': 'Erreur serveur (${response.statusCode})',
        };
      }
    } catch (e) {
      return {'success': false, 'message': 'Impossible de joindre le serveur.'};
    }
  }

  static Future<Map<String, dynamic>> updateComment({
    required int id,
    required String message,
  }) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/signalements/commentaires/$id'),
        headers: _headers,
        body: jsonEncode({'contenu': message, 'message': message}),
      );
      if (response.statusCode == 200) {
        return {'success': true, 'data': jsonDecode(response.body)};
      }
      return {'success': false, 'message': 'Erreur de mise à jour'};
    } catch (e) {
      return {'success': false, 'message': 'Impossible de joindre le serveur.'};
    }
  }

  static Future<Map<String, dynamic>> deleteComment(int id) async {
    try {
      final response = await http.delete(
        Uri.parse('$baseUrl/signalements/commentaires/$id'),
        headers: _headers,
      );
      if (response.statusCode == 200) {
        return {'success': true, 'message': 'Commentaire supprimé'};
      }
      return {'success': false, 'message': 'Erreur de suppression'};
    } catch (e) {
      return {'success': false, 'message': 'Impossible de joindre le serveur.'};
    }
  }
}
