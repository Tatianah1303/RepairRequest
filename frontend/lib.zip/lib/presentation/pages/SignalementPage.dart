import 'package:flutter/material.dart';
import '../../application/usecases.dart';
import 'discussionPage.dart';
import '../pages/AcceuilPage.dart';

class SignalementPage extends StatefulWidget {
  const SignalementPage({super.key});

  @override
  State<SignalementPage> createState() => _SignalementPageState();
}

class _SignalementPageState extends State<SignalementPage> {
  final titreController = TextEditingController();
  final descriptionController = TextEditingController();
  final batimentController = TextEditingController();
  final adresseController = TextEditingController();
  final quartierController = TextEditingController();

  Future<void> envoyerSignalement() async {
    final result = await UseCases.createSignalement(
      titre: titreController.text,
      description: descriptionController.text,
      batiment: batimentController.text,
      adresse: adresseController.text,
      quartier: quartierController.text,
    );

    if (result['success'] == true) {
      final int? createdId = result['createdId'];

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Signalement créé avec succès")),
      );

      if (createdId != null) {
        // 👉 Ouvrir directement la DiscussionPage du signalement créé
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => DiscussionPage(signalementId: createdId),
          ),
        );
      } else {
        // 👉 Si pas d’ID, retour à l’accueil
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const AccueilPage()),
        );
      }
    } else {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(result['message'] ?? "Erreur")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Nouveau Signalement"),
        backgroundColor: const Color(0xFF6A1B9A),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            TextField(
              controller: titreController,
              decoration: const InputDecoration(labelText: "Titre"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: descriptionController,
              decoration: const InputDecoration(labelText: "Description"),
              maxLines: 3,
            ),
            const SizedBox(height: 10),
            TextField(
              controller: batimentController,
              decoration: const InputDecoration(labelText: "Bâtiment"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: adresseController,
              decoration: const InputDecoration(labelText: "Adresse"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: quartierController,
              decoration: const InputDecoration(labelText: "Quartier"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: envoyerSignalement,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF6A1B9A),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: const Text("Envoyer"),
            ),
          ],
        ),
      ),
    );
  }
}
