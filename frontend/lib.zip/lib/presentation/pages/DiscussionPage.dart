import 'package:flutter/material.dart';
import '../../application/usecases.dart';

class DiscussionPage extends StatefulWidget {
  final int signalementId;
  const DiscussionPage({super.key, required this.signalementId});

  @override
  State<DiscussionPage> createState() => _DiscussionPageState();
}

class _DiscussionPageState extends State<DiscussionPage> {
  Map<String, dynamic>? signalementData;
  final TextEditingController messageController = TextEditingController();
  List<Map<String, dynamic>> commentaires = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    loadSignalement();
    loadCommentaires();
  }

  Future<void> loadSignalement() async {
    final result = await UseCases.getSignalementById(widget.signalementId);
    if (result['success'] == true) {
      setState(() {
        signalementData = result['data'];
        isLoading = false;
      });
    } else {
      setState(() {
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result['message'] ?? "Erreur de chargement")),
      );
    }
  }

  Future<void> loadCommentaires() async {
    final result = await UseCases.getCommentaires(widget.signalementId);
    if (result['success'] == true) {
      setState(() {
        commentaires = List<Map<String, dynamic>>.from(result['data']);
      });
    }
  }

  Future<void> envoyerMessage() async {
    if (messageController.text.trim().isEmpty) return;

    final result = await UseCases.addCommentaire(
      idSignalement: widget.signalementId,
      contenu: messageController.text,
    );
    if (result['success'] == true) {
      messageController.clear();
      loadCommentaires(); // recharger la liste
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result['message'] ?? "Erreur d'envoi")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: signalementData == null
            ? const Text("Discussion")
            : Text(
                "Signalement #${widget.signalementId} – "
                "${signalementData!['titre']} (${signalementData!['quartier']})",
              ),
        backgroundColor: const Color(0xFF6A1B9A),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: ClipOval(
              child: Image.asset(
                'assets/logo.png',
                height: 40,
                width: 40,
                fit: BoxFit.cover,
              ),
            ),
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(
                  child: commentaires.isEmpty
                      ? const Center(child: Text("Aucun commentaire"))
                      : ListView.builder(
                          padding: const EdgeInsets.all(12),
                          itemCount: commentaires.length,
                          itemBuilder: (_, i) {
                            final c = commentaires[i];
                            return Card(
                              margin: const EdgeInsets.symmetric(vertical: 6),
                              child: ListTile(
                                leading: const Icon(Icons.person),
                                title: Text(c['auteur'] ?? 'Utilisateur'),
                                subtitle: Text(c['contenu'] ?? ''),
                              ),
                            );
                          },
                        ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: messageController,
                          decoration: const InputDecoration(
                            hintText: "Écrire un message...",
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.send, color: Color(0xFF6A1B9A)),
                        onPressed: envoyerMessage,
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}
