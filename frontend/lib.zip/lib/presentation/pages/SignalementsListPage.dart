import 'package:flutter/material.dart';
import '../../application/usecases.dart';
import 'SignalementPage.dart';
import 'DiscussionPage.dart';
import 'EditSignalementPage.dart';

class SignalementsListPage extends StatefulWidget {
  const SignalementsListPage({super.key});

  @override
  State<SignalementsListPage> createState() => _SignalementsListPageState();
}

class _SignalementsListPageState extends State<SignalementsListPage> {
  List<Map<String, dynamic>> signalements = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    loadSignalements();
  }

  Future<void> loadSignalements() async {
    final result = await UseCases.loadSignalements();
    if (result['success'] == true) {
      setState(() {
        signalements = List<Map<String, dynamic>>.from(result['data'] ?? []);
        isLoading = false;
      });
    } else {
      setState(() {
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result['message'] ?? "Erreur de chargement")),
      );
    }
  }

  Future<void> deleteSignalement(int id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Supprimer'),
        content: const Text('Voulez-vous vraiment supprimer ce signalement ?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Annuler'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Supprimer', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      final result = await UseCases.deleteSignalement(id);
      if (result['success'] == true) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text("Signalement supprimé")));
        loadSignalements();
      } else {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(result['message'] ?? "Erreur")));
      }
    }
  }

  Color _getStatusColor(String statut) {
    switch (statut) {
      case 'en attente':
        return Colors.red;
      case 'en cours':
        return Colors.orange;
      case 'refusé':
        return Colors.grey;
      case 'terminé':
        return Colors.green;
      default:
        return Colors.blue;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Signalements"),
        backgroundColor: const Color(0xFF6A1B9A),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : signalements.isEmpty
          ? const Center(child: Text("Aucun signalement"))
          : ListView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: signalements.length,
              itemBuilder: (_, i) {
                final sig = signalements[i];
                return Card(
                  margin: const EdgeInsets.symmetric(vertical: 6),
                  child: ExpansionTile(
                    title: Text(
                      sig['titre'] ?? 'Sans titre',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: _getStatusColor(sig['statut'] ?? ''),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            sig['statut'] ?? 'N/A',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(sig['quartier'] ?? 'N/A'),
                      ],
                    ),
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Description:',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(sig['description'] ?? ''),
                            const SizedBox(height: 8),
                            Text(
                              'Bâtiment: ${sig['batiment'] ?? 'N/A'} | Adresse: ${sig['adresse'] ?? 'N/A'}',
                            ),
                            const SizedBox(height: 16),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                ElevatedButton.icon(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFF6A1B9A),
                                  ),
                                  icon: const Icon(Icons.chat),
                                  label: const Text('Discuter'),
                                  onPressed: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => DiscussionPage(
                                          signalementId:
                                              sig['id_signalement'] ??
                                              sig['id'] ??
                                              0,
                                        ),
                                      ),
                                    );
                                  },
                                ),
                                ElevatedButton.icon(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.blue,
                                  ),
                                  icon: const Icon(Icons.edit),
                                  label: const Text('Éditer'),
                                  onPressed: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => EditSignalementPage(
                                          signalement: sig,
                                        ),
                                      ),
                                    ).then((updated) {
                                      if (updated == true) {
                                        loadSignalements();
                                      }
                                    });
                                  },
                                ),
                                ElevatedButton.icon(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.red,
                                  ),
                                  icon: const Icon(Icons.delete),
                                  label: const Text('Supprimer'),
                                  onPressed: () {
                                    deleteSignalement(
                                      sig['id_signalement'] ?? sig['id'] ?? 0,
                                    );
                                  },
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFF6A1B9A),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const SignalementPage()),
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
