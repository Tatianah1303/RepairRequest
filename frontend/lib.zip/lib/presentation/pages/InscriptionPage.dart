import 'package:flutter/material.dart';
import '../../application/usecases.dart';

class InscriptionPage extends StatefulWidget {
  const InscriptionPage({super.key});

  @override
  State<InscriptionPage> createState() => _InscriptionPageState();
}

class _InscriptionPageState extends State<InscriptionPage> {
  late TextEditingController nomController;
  late TextEditingController emailController;
  late TextEditingController motdepasseController;
  late TextEditingController specialiteController;
  String role = 'resident';

  @override
  void initState() {
    super.initState();
    nomController = TextEditingController();
    emailController = TextEditingController();
    motdepasseController = TextEditingController();
    specialiteController = TextEditingController();
  }

  @override
  void dispose() {
    nomController.dispose();
    emailController.dispose();
    motdepasseController.dispose();
    specialiteController.dispose();
    super.dispose();
  }

  Future<void> inscrire() async {
    // Validation basique
    if (nomController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Le nom est obligatoire'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    if (emailController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('L\'email est obligatoire'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    if (motdepasseController.text.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Le mot de passe doit contenir au moins 6 caractères'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    if (role == 'technicien' && specialiteController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('La spécialité est obligatoire pour un technicien'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final result = await UseCases.registerUser(
      nom: nomController.text,
      email: emailController.text,
      motDePasse: motdepasseController.text,
      role: role,
      specialite: role == 'technicien' ? specialiteController.text : null,
    );

    if (result['success'] == true) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Inscription réussie !'),
          backgroundColor: Colors.green,
        ),
      );
      Navigator.pop(context); // retour à la ConnexionPage
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(result['message'] ?? 'Erreur d\'inscription'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Inscription"),
        backgroundColor: const Color(0xFF6A1B9A),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            TextField(
              controller: nomController,
              decoration: const InputDecoration(labelText: 'Nom'),
            ),
            TextField(
              controller: emailController,
              decoration: const InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: motdepasseController,
              decoration: const InputDecoration(labelText: 'Mot de passe'),
              obscureText: true,
            ),
            DropdownButton<String>(
              value: role,
              items: const [
                DropdownMenuItem(value: 'resident', child: Text('Résident')),
                DropdownMenuItem(
                  value: 'technicien',
                  child: Text('Technicien'),
                ),
                DropdownMenuItem(value: 'admin', child: Text('Admin')),
              ],
              onChanged: (v) {
                setState(() {
                  role = v ?? 'resident';
                });
              },
            ),
            if (role == 'technicien')
              TextField(
                controller: specialiteController,
                decoration: const InputDecoration(labelText: 'Spécialité'),
              ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: inscrire,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF6A1B9A),
                foregroundColor: Colors.white,
              ),
              child: const Text("S'inscrire"),
            ),
          ],
        ),
      ),
    );
  }
}
