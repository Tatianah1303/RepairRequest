import 'package:flutter/material.dart';
import '../../application/usecases.dart';

class EditSignalementPage extends StatefulWidget {
  final Map<String, dynamic> signalement;

  const EditSignalementPage({super.key, required this.signalement});

  @override
  State<EditSignalementPage> createState() => _EditSignalementPageState();
}

class _EditSignalementPageState extends State<EditSignalementPage> {
  late TextEditingController titreController;
  late TextEditingController descriptionController;
  late TextEditingController batimentController;
  late TextEditingController adresseController;
  late TextEditingController quartierController;
  late String statut;

  @override
  void initState() {
    super.initState();
    titreController = TextEditingController(
      text: widget.signalement['titre'] ?? '',
    );
    descriptionController = TextEditingController(
      text: widget.signalement['description'] ?? '',
    );
    batimentController = TextEditingController(
      text: widget.signalement['batiment'] ?? '',
    );
    adresseController = TextEditingController(
      text: widget.signalement['adresse'] ?? '',
    );
    quartierController = TextEditingController(
      text: widget.signalement['quartier'] ?? '',
    );
    statut = widget.signalement['statut'] ?? 'en attente';
  }

  @override
  void dispose() {
    titreController.dispose();
    descriptionController.dispose();
    batimentController.dispose();
    adresseController.dispose();
    quartierController.dispose();
    super.dispose();
  }

  Future<void> sauvegarder() async {
    final result = await UseCases.updateSignalement(
      id: widget.signalement['id_signalement'] ?? widget.signalement['id'] ?? 0,
      titre: titreController.text,
      description: descriptionController.text,
      batiment: batimentController.text,
      adresse: adresseController.text,
      quartier: quartierController.text,
      statut: statut,
    );

    if (result['success'] == true) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Signalement mis à jour")));
      Navigator.pop(context, true);
    } else {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(result['message'] ?? "Erreur")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Éditer Signalement"),
        backgroundColor: const Color.fromARGB(255, 42, 224, 149),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            TextField(
              controller: titreController,
              decoration: const InputDecoration(labelText: "Titre"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: descriptionController,
              decoration: const InputDecoration(labelText: "Description"),
              maxLines: 3,
            ),
            const SizedBox(height: 10),
            TextField(
              controller: batimentController,
              decoration: const InputDecoration(labelText: "Bâtiment"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: adresseController,
              decoration: const InputDecoration(labelText: "Adresse"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: quartierController,
              decoration: const InputDecoration(labelText: "Quartier"),
            ),
            const SizedBox(height: 10),
            DropdownButton<String>(
              value: statut,
              isExpanded: true,
              items: const [
                DropdownMenuItem(
                  value: 'en attente',
                  child: Text('En attente'),
                ),
                DropdownMenuItem(value: 'en cours', child: Text('En cours')),
                DropdownMenuItem(value: 'refusé', child: Text('Refusé')),
                DropdownMenuItem(value: 'terminé', child: Text('Terminé')),
              ],
              onChanged: (v) {
                setState(() {
                  statut = v ?? 'en attente';
                });
              },
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: sauvegarder,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF6A1B9A),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              child: const Text("Sauvegarder"),
            ),
          ],
        ),
      ),
    );
  }
}
