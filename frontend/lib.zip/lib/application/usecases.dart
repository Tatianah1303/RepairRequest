import '../infrastructure/services.dart';

class UseCases {
  // 🔐 Auth
  static Future<Map<String, dynamic>> registerUser({
    required String nom,
    required String email,
    required String motDePasse,
    required String role,
    String? specialite,
  }) => Services.register(
    nom: nom,
    email: email,
    motDePasse: motDePasse,
    role: role,
    specialite: specialite,
  );

  static Future<Map<String, dynamic>> loginUser({
    required String email,
    required String motDePasse,
  }) => Services.login(email: email, motDePasse: motDePasse);

  // 🏢 Signalement
  static Future<Map<String, dynamic>> createSignalement({
    required String titre,
    required String description,
    required String batiment,
    required String adresse,
    required String quartier,
  }) async {
    final result = await Services.createSignalement(
      titre: titre,
      description: description,
      batiment: batiment,
      adresse: adresse,
      quartier: quartier,
    );
    return result; // contient aussi createdId
  }

  // 🏢 Récupérer tous les signalements
  static Future<Map<String, dynamic>> loadSignalements() =>
      Services.loadSignalements();

  // 🔎 Récupérer un signalement par ID
  static Future<Map<String, dynamic>> getSignalementById(int idSignalement) =>
      Services.getSignalementById(idSignalement);

  // ✏️ Éditer un signalement
  static Future<Map<String, dynamic>> updateSignalement({
    required int id,
    required String titre,
    required String description,
    required String batiment,
    required String adresse,
    required String quartier,
    required String statut,
  }) => Services.updateSignalement(
    id: id,
    titre: titre,
    description: description,
    batiment: batiment,
    adresse: adresse,
    quartier: quartier,
    statut: statut,
  );

  // 🗑️ Supprimer un signalement
  static Future<Map<String, dynamic>> deleteSignalement(int id) =>
      Services.deleteSignalement(id);

  // 💬 Discussion
  static Future<Map<String, dynamic>> addCommentaire({
    required int idSignalement,
    required String contenu,
  }) async {
    final result = await Services.sendComment(
      message: contenu,
      signalementId: idSignalement,
    );
    return result;
  }

  static Future<Map<String, dynamic>> getCommentaires(int idSignalement) async {
    final data = await Services.loadComments(idSignalement);
    return {'success': true, 'data': data};
  }

  // ✏️ Éditer un commentaire
  static Future<Map<String, dynamic>> updateCommentaire({
    required int id,
    required String contenu,
  }) => Services.updateComment(id: id, message: contenu);

  // 🗑️ Supprimer un commentaire
  static Future<Map<String, dynamic>> deleteCommentaire(int id) =>
      Services.deleteComment(id);

  // 👥 Users
  static Future<Map<String, dynamic>> loadUsers() => Services.fetchUsers();

  // 📊 Statistiques des signalements
  static Future<Map<String, dynamic>> loadStats() => Services.loadStats();
}

/*import '../infrastructure/services.dart';

class UseCases {
  // 🔐 Auth
  static Future<Map<String, dynamic>> registerUser({
    required String nom,
    required String email,
    required String motDePasse,
    required String role,
    String? specialite,
  }) => Services.register(
    nom: nom,
    email: email,
    motDePasse: motDePasse,
    role: role,
    specialite: specialite,
  );

  static Future<Map<String, dynamic>> loginUser({
    required String email,
    required String motDePasse,
  }) => Services.login(email: email, motDePasse: motDePasse);

  // 🏢 Signalement
  static Future<Map<String, dynamic>> createSignalement({
    required String titre,
    required String description,
    required String batiment,
    required String adresse,
    required String quartier,
  }) async {
    final result = await Services.createSignalement(
      titre: titre,
      description: description,
      batiment: batiment,
      adresse: adresse,
      quartier: quartier,
    );
    return result; // contient aussi createdId
  }

  // 🏢 Récupérer tous les signalements
  static Future<Map<String, dynamic>> loadSignalements() =>
      Services.loadSignalements();

  // 🔎 Récupérer un signalement par ID
  static Future<Map<String, dynamic>> getSignalementById(int idSignalement) =>
      Services.getSignalementById(idSignalement);

  // ✏️ Éditer un signalement
  static Future<Map<String, dynamic>> updateSignalement({
    required int id,
    required String titre,
    required String description,
    required String batiment,
    required String adresse,
    required String quartier,
    required String statut,
  }) => Services.updateSignalement(
    id: id,
    titre: titre,
    description: description,
    batiment: batiment,
    adresse: adresse,
    quartier: quartier,
    statut: statut,
  );

  // 🗑️ Supprimer un signalement
  static Future<Map<String, dynamic>> deleteSignalement(int id) =>
      Services.deleteSignalement(id);

  // 💬 Discussion
  static Future<Map<String, dynamic>> addCommentaire({
    required int idSignalement,
    required String contenu,
  }) async {
    final result = await Services.sendComment(
      message: contenu,
      signalementId: idSignalement,
    );
    return result;
  }

  static Future<Map<String, dynamic>> getCommentaires(int idSignalement) async {
    final data = await Services.loadComments(idSignalement);
    return {'success': true, 'data': data};
  }

  // ✏️ Éditer un commentaire
  static Future<Map<String, dynamic>> updateCommentaire({
    required int id,
    required String contenu,
  }) => Services.updateComment(id: id, message: contenu);

  // 🗑️ Supprimer un commentaire
  static Future<Map<String, dynamic>> deleteCommentaire(int id) =>
      Services.deleteComment(id);

  // 👥 Users
  static Future<Map<String, dynamic>> loadUsers() => Services.fetchUsers();

  // 📊 Statistiques des signalements
  static Future<Map<String, dynamic>> loadStats() => Services.loadStats();
}*/
